# Exemple de dépôt Mosaune

Paquets de démonstration : Ambre et TMDB. Aucun réglage, compte ou secret.

Dans un dépôt GitHub public, placez mosaune-repository.json et le dossier packages à la racine. Dans Mosaune 0.0.20 ou plus : Réglages → Extensions → À télécharger → Gérer les dépôts GitHub. Ajoutez l'adresse https://github.com/VOTRE-COMPTE/VOTRE-DEPOT. Laissez la référence vide pour la branche par défaut.

L'empreinte sha256 de chaque fiche est celle du fichier ZIP complet. Ne modifiez pas un paquet sans mettre à jour sa fiche. TMDB reste signé par la clé de développement du projet, sans autoriser d'autres signatures. Les deux versions TMDB ont les mêmes fonctions : elles servent à tester les mises à jour et le retour arrière.
